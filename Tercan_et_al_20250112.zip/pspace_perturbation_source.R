library(PathwaySpace)
library(igraph)
library(data.table)
library(ggplot2)
library(ggridges)

################################################################################
### Custom functions for PathwaySpace perturbation
################################################################################

#-------------------------------------------------------------------------------
# A function to wrap up PathwaySpace distance calls
# Note: distance 'from' and 'to' disconnected nodes will the set to 'maxdist'
get_ps_distances <- function(g, L1, L2, maxdist, nperm=2000){ 
  gdist <- igraph::distances(graph = g, algorithm="unweighted")
  gdist[gdist==Inf] <- maxdist + 1
  pdist <- pathDistances(gdist=gdist, from = L1, to = L2, nperm = nperm)
  return(pdist)
}

#-------------------------------------------------------------------------------
# A function to rewire random edges
rewire_random_edges <- function(g, perturbation = 0.1){
  pt <- ecount(g) * perturbation
  rg <- rewire(g, with = keeping_degseq(niter = pt) )
  d <- get_elist_dissimilarity(g, rg)
  res <- list(rg = rg, dissimilarity = d )
  return(res)
}
get_elist_dissimilarity <- function(g1, g2){
  el_g1 <- as_edgelist(g1)
  el_g1 <- paste0(el_g1[, 1],"~", el_g1[, 2])
  el_g2 <- as_edgelist(g2); el_g2 <- paste0(el_g2[, 1],"~", el_g2[, 2])
  el_g2rev <- as_edgelist(g2); el_g2rev <- paste0(el_g2rev[, 2],"~", el_g2rev[, 1])
  d <- 1 - sum(el_g1 %in% el_g2 | el_g1 %in% el_g2rev)/length(el_g1)
  return(d)
}

#-------------------------------------------------------------------------------
# A function to permute random nodes
permute_random_nodes <- function(g, perturbation = 0.1){
  rg <- g
  pt <- vcount(rg) * perturbation
  idx <- sample(vcount(rg), as.integer(pt))
  V(rg)$name[idx] <- sample(V(rg)$name[idx])
  d <- get_nlist_dissimilarity(g, rg)
  res <- list(rg = rg, dissimilarity = d )
  return(res)
}
get_nlist_dissimilarity <- function(g1, g2){
  d <- sum(V(g1)$name!=V(g2)$name)/vcount(g1)
  return(d)
}

#-------------------------------------------------------------------------------
# A function to remove random edges
remove_random_edges <- function(g, perturbation = 0.1){
  rg <- g
  pt <- ecount(rg) * perturbation
  to_remove <- sample(ecount(rg), as.integer(pt))
  rg <- delete_edges(rg, to_remove)
  d <- get_elist_dissimilarity(g, rg)
  res <- list(rg = rg, dissimilarity = d )
  return(res)
}

#-------------------------------------------------------------------------------
# A function to disconnect random nodes
disconnect_random_nodes <- function(g, perturbation = 0.1){
  rg <- g
  pt <- vcount(rg) * perturbation
  idx <- sample(vcount(rg), as.integer(pt))
  neighbors <- ego(g, nodes=idx)
  to_remove <- sapply(seq_along(neighbors), function(i){
    v <- names(neighbors[[i]])
    paste0(v[1],"|",v[-c(1)])
  })
  to_remove <- unlist(to_remove)
  rg <- delete_edges(rg, to_remove)
  d <- get_elist_dissimilarity(g, rg)
  res <- list(rg = rg, dissimilarity = d )
  return(res)
}

#-------------------------------------------------------------------------------
# A function to disconnect target nodes
disconnect_topk_nodes <- function(g, perturbation = 0.1){
  rg <- g
  top_k_nodes <- degree(rg)
  top_k_nodes <- sort(top_k_nodes, decreasing = TRUE)[seq_len(1000)]
  top_k_nodes <- names(top_k_nodes)
  pt <- length(top_k_nodes) * perturbation
  top_k_nodes <- sample(top_k_nodes, as.integer(pt))
  neighbors <- ego(g, nodes=top_k_nodes)
  to_remove <- sapply(seq_along(neighbors), function(i){
    v <- names(neighbors[[i]])
    paste0(v[1],"|",v[-c(1)])
  })
  to_remove <- unlist(to_remove)
  rg <- delete_edges(rg, to_remove)
  d <- get_elist_dissimilarity(g, rg)
  res <- list(rg = rg, dissimilarity = d )
  return(res)
}

#-------------------------------------------------------------------------------
# A function to assess distances between two gene lists for different
# pathway space perturbation methods
perturbation_test <- function(g, L1, L2, nperm=2000, 
  method = c("rewire.edges", "permute.nodes", "remove.edges", 
    "disconnect.nodes", "disconnect.hubs")){
  method <- match.arg(method)
  if(method=="rewire.edges"){
    fun <- rewire_random_edges
    perturbations <-  1 - log10(rev(seq_len(10)))
    perturbations <- c(perturbations, 2)
  } else if(method=="permute.nodes"){
    fun <- permute_random_nodes
    perturbations <-  seq(0,0.9,0.1)
  } else if(method=="remove.edges"){
    fun <- remove_random_edges
    perturbations <-  seq(0,0.9,0.1)
  } else if(method=="disconnect.nodes"){
    fun <- disconnect_random_nodes
    perturbations <-  seq(0,0.9,0.1)
  } else {
    fun <- disconnect_topk_nodes
    perturbations <-  seq(0,0.9,0.1)
  }
  odists <- NULL #observed distances between L1 and L2
  ndists <- NULL #null distances between L1 and L2
  dlevel <- NULL #dissimilarity level between original and perturbed graphs
  maxdist <- igraph::distances(graph = g, algorithm="unweighted")
  maxdist[maxdist==Inf] <- NA
  maxdist <- max(maxdist, na.rm = TRUE)
  for(pt in perturbations){
    pt_graph <- fun(g, pt)
    res <- get_ps_distances(pt_graph$rg, L1, L2, maxdist, nperm=nperm)
    dlevel <- c(dlevel, pt_graph$dissimilarity)
    ndists <- cbind(ndists, res$p_dist$null)
    odists <- c(odists, res$p_dist$obs)
    cat("\n")
  }
  colnames(ndists) <- names(odists) <- names(dlevel) <- paste0("pt_", perturbations)
  dist_df <- melt(as.data.table(ndists), measure.vars=colnames(ndists))
  dist_df <- as.data.frame(dist_df)
  colnames(dist_df) <- c("perturbation", "null_distances")
  similarity <- 1 - dlevel
  dist_df$similarity <- similarity[dist_df$perturbation]
  alpha05 <- apply(ndists, 2, quantile, probs=0.05)
  rejection <- c('No', 'Yes')[ (odists < alpha05) + 1 ]
  lim <- range(c(ndists, odists))
  results <- list(dist_df=dist_df, ndists=ndists, odists=odists, range = lim,
    similarity=similarity, alpha05=alpha05, rejection=rejection, 
    L1=L1, L2=L2, method=method)
  return(results)
}

#-------------------------------------------------------------------------------
plot_perturbations <- function(results){
  dist_df <- results$dist_df
  similarity <- results$similarity
  observed_dists <- results$odists
  method <- results$method
  rejection_region <- results$rejection
  cols1 <- c("black", "red")[(rejection_region=="Yes") + 1]
  cols2 <- c("white", "red")[(rejection_region=="Yes") + 1]
  if(method=="rewire.edges"){
    lab <- "Random perturbations\nby rewiring edges"
  } else if(method=="permute.nodes"){
    lab <- "Random perturbations\nby permuting nodes"
  } else if(method=="remove.edges"){
    lab <- "Random perturbations\nby removing edges"
  } else if(method=="disconnect.nodes"){
    lab <- "Random perturbations\nby disconnecting nodes"
  } else if(method=="disconnect.hubs"){
    lab <- "Random perturbations\nby disconnecting hubs"
  } else {
    lab <- ""
  }
  gg <- ggplot(dist_df, 
    aes(x=null_distances, y=similarity, group=similarity, fill = factor(after_stat(quantile)) )) +
    geom_density_ridges_gradient(mapping = aes(height= after_stat(ndensity), scale = 0.8),
      color = "grey20", lwd=0.1, quantile_lines = TRUE, alpha = .5, quantiles=0.05, bandwidth=0.35) +
    scale_fill_manual(values = c('1'="black", '2'="grey")) +
    scale_y_continuous(limits = c(0,1.09), breaks = c(0,2,4,6,8,10)/10) +
    ylab("Similarity between reference and perturbed graphs") + 
    xlab("Distance between gene lists (steps)") +
    ggtitle(lab) + theme_minimal() +
    theme(plot.title = element_text(size=14, hjust = 0.5, vjust = 0), 
      legend.position = "none")
  gg <- gg + annotate("point", y = similarity+0.015, x = observed_dists, 
    pch = 25, size = 2.5, stroke=0.7, col = cols1, fill=cols2)
  return(gg)
}

#-------------------------------------------------------------------------------
# gg <- ggplot(res_rewire$dist_df, aes(x=rewiring, y=null_distances, group=rewiring)) +
#   geom_boxplot(outlier.shape=NA, fill="grey", alpha=0.2) +
#   xlab("Random rewiring rate") + ylab("Distance between gene lists (steps)") +
#   ggtitle("Pathway space perturbations") + theme_light()
# gg <- gg + annotate("point", x = res_rewire$dlevel, y = res_rewire$odists,
#   pch = 24, size = 3, fill = threshold)
# pdf(file = "perturbations.pdf", width = 4, height = 3.5)
# plot(gg)
# dev.off()

