#' =============================================================================
#' Script Name: 'pspace_perturbation.R'
#' =============================================================================
#' Description:
#' This R script has been developed to reproduce the results presented in 
#' Figure S1 of Tercan et al. (2025). The script covers the following steps:
#' 1. Data loading and preprocessing
#' 2. Statistical analysis
#' 3. Visualization of results to match Figure S1
#' 
#' Ensure that all required packages and datasets are installed and available 
#' before running the script.
#' =============================================================================
#' Authors: Bahar Tercan, Gordon Robertson, Mauro Castro
#' Date Created: 2025-01-11
#' Last Updated: 2025-01-11
#' Contact Information: [mauro.a.castro@gmail.com]
#' =============================================================================
#' Requirements:
#' - R version >=4.4.2
#' - Required R packages: PathwaySpace, igraph, ggplot2, data.table, dplyr, ggridges
#' - Input data: all required datasets are available in the PathwaySpace package
#' - Supporting file: 'pspace_perturbation_source.R' (distributed alongside this script)
#' =============================================================================
#' Instructions:
#' 1. Set the working directory to the location of this script.
#' 2. Ensure this script and the 'pspace_perturbation_source.R' file are in the 
#' same directory. Both files are distributed together.
#' 2. Verify that all required dependencies are installed.
#' 3. Run the script section by section.
#' =============================================================================
#' References:
#' Tercan et al. A protocol to assess pathway space distances between
#' classifier feature sets. STAR Protocols, 2025 (under review)
#' =============================================================================
#' Notes:
#' - This script assumes that the input data is formatted as described in the 
#'   publication. Any preprocessing steps required to adapt the data should 
#'   be completed before running the script.
#' - If any issues arise, please refer to the documentation or contact the author.
#' =============================================================================

################################################################################
### Load required libraries
################################################################################
library(PathwaySpace) # PathwaySpace_1.0.1
library(igraph)       # igraph_2.1.2
library(data.table)   # data.table_1.16.4
library(ggplot2)      # ggplot2_3.5.1
library(ggridges)     # igraph_2.1.2

################################################################################
### Load required source code
################################################################################
source("pspace_perturbation_source.R")

################################################################################
### Load Pathway Commons V12
################################################################################
# Load Pathway Commons V12
data("PCv12_pruned_igraph", package = "PathwaySpace")

################################################################################
### Get two non-overlapping gene lists from the same neighborhood
################################################################################
#--- Extract neighborhood of a vertex
neighbors <- ego(PCv12_pruned_igraph, nodes="TP53")
neighbors <- names(unlist(neighbors))
length(neighbors)
# 258
#--- Get gene lists, L1 and L2
L1 <- sample(neighbors, 50)
L2 <- setdiff(neighbors, L1)[seq_len(50)]
any(L1 %in% L2)
# [1] FALSE

################################################################################
###  Run perturbation_test() function, for method = 'rewire.edges'
################################################################################
res_rewire <- perturbation_test(PCv12_pruned_igraph, L1, L2, method = "rewire.edges")
gg <- plot_perturbations(res_rewire)
pdf(file = "perturbation_rewire_edges.pdf", width = 3, height = 5.5)
plot(gg)
dev.off()

################################################################################
###  Run perturbation_test() function, for method = 'permute.nodes'
################################################################################
res_permute <- perturbation_test(PCv12_pruned_igraph, L1, L2, method = "permute.nodes")
gg <- plot_perturbations(res_permute)
pdf(file = "perturbation_permute_nodes.pdf", width = 3, height = 5.5)
plot(gg)
dev.off()

################################################################################
###  Run perturbation_test() function, for method = 'remove.edges'
################################################################################
res_remove <- perturbation_test(PCv12_pruned_igraph, L1, L2, method = "remove.edges")
gg <- plot_perturbations(res_remove)
pdf(file = "perturbation_remove_edges.pdf", width = 3, height = 5.5)
plot(gg)
dev.off()

################################################################################
###  Run perturbation_test() function, for method = 'disconnect.nodes'
################################################################################
res_disconnect <- perturbation_test(PCv12_pruned_igraph, L1, L2, method = "disconnect.nodes")
gg <- plot_perturbations(res_disconnect)
pdf(file = "perturbation_disconnect_nodes.pdf", width = 3, height = 5.5)
plot(gg)
dev.off()

################################################################################
###  Run perturbation_test() function, for method = 'disconnect.hubs'
################################################################################
res_disconnect_hubs <- perturbation_test(PCv12_pruned_igraph, L1, L2, method = "disconnect.hubs")
gg <- plot_perturbations(res_disconnect_hubs)
pdf(file = "perturbation_disconnect_hubs.pdf", width = 3, height = 5.5)
plot(gg)
dev.off()

#-------------------------------------------------------------------------------
# To save the relevant objects for reproducing results and generating plots
save(res_rewire, res_permute, res_remove, res_disconnect, res_disconnect_hubs,
  file = "pspace_perturbation_results.RData")

